
- [ ] Rewrite this a Lua rock spec.
